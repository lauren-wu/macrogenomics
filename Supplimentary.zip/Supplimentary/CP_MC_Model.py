'''
Calculate gene expression sensitivity based on the output of Monte Carlo 
and Brownian Dynamics output. The model predicted data is calculated using both
direct simulation data fitting (sensitivity_model.csv) and the g function (sensitivity_model_g.csv). 
The sentivity of expression measured by Microarray experiment is also calculated here.
written by Wenli Wu, last edited Sep 19, 2017
Any questions related to the code, please email:wenliwu2018@u.northwestern.edu
'''

import numpy as np
import os,sys,glob
import pandas as pd
import time
from sympy.solvers import solve
from sympy import Symbol
import sympy as sp
from scipy import stats
import scipy.special as sc
import macrogenomics

## Define the in cell function ######
def magic(str2):
    numList=[int(s) for s in str2 if s.isdigit()]
    s = ''.join(map(str, numList))
    return int(s)
      
#######################################################################
#### Output the relation with initial expression ##############
#######################################################################
cpmc = macrogenomics.cp_mc()
n_quantile = 30## number of quantiles
Se=np.zeros((4,n_quantile))
initial=np.zeros((4,n_quantile))

#### Output the experimental data ##########
for m in range(4):
    percentile_norm,Se[m,:] = cpmc.se_experiment(n_quantile,m)
error = stats.sem(Se)
C0,ld,D_List,ldlist = cpmc.Ld_D()#C0=dD/dLd
p = np.vstack((percentile_norm[1:],Se.mean(axis=0)[1:]*cpmc.D_fit/(C0*ld),error[1:])).transpose()
np.savetxt('sensitivity_experiment.csv',p,delimiter=',')

#### Output the simulation prediction ##########
Se,expression,ratio=cpmc.se()
x = np.log(expression/cpmc.initial_aver)
# print(x)
y = Se
y = y[~np.isnan(x)]
x = x[~np.isnan(x)]
para2 = np.poly1d(np.polyfit(x,y,10))
x = np.linspace(-2.,2.8,100)
p = np.vstack((x,para2(x))).transpose()
np.savetxt("sensitivity_model.csv",p,delimiter=',',fmt='%.9f')

### Output function g ####
param_a,x,g_f=cpmc.g_fit(cpmc.D_fit)
p=np.vstack((x,g_f)).transpose()
np.savetxt('g_function.csv',p)
print("the critical rate of expression of g function, kappa, is: ",param_a[0]*10**6," nM/s")

#### Output sensitivity calculated from g function
x = np.linspace(-2.,2.8,100)
exp_g=np.exp(x)*cpmc.initial_aver
y=cpmc.se_g(exp_g)
p = np.vstack((x,y)).transpose()
np.savetxt("sensitivity_model_g.csv",p,delimiter=',',fmt='%.9f')





