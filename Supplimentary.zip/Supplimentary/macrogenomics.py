'''
Calculate the gene expression sensitivity the scaling of chromatin density model
writtern by Wenli Wu, last edited Sep 19, 2017
any questions related to the code, please send the email to : wenliwu2018@u.northwestern.edu

'''
import numpy as np
import os,sys,glob
import pandas as pd
import time
from sympy.solvers import solve
from sympy import Symbol
import sympy as sp
from scipy import stats
from scipy.stats import norm
import scipy.optimize 
import scipy.special as sc
from scipy.optimize import curve_fit

class cp_mc:
    '''
    The Chromatin Packing Molecular Crowding Model
	''' 
    ## load experiment Data
    data = pd.read_excel('full_genes.xlsx',header=None).values
    data_norm = np.log(data/np.mean(data))
    ld_exp=np.array([1.001, 1., 0.9933, 0.9151]) # Relative Ld value
    control=0 ## number of group used as the control group in each treatment ##
    control_start=0

    ## Molecular Crowding output and Chromatin Packing parameters
    sec          =np.genfromtxt('second_derivative_TF_norm.csv')
    mRNA_initial =np.genfromtxt('max_mRNA_initial.csv')
    phi_initial  =np.genfromtxt('phi_initial.csv')
    tot_con      =np.genfromtxt('tot_con.csv')
    D_fit        =2.68 ## The average D of cells
    norm_fit     =0.8 # normalization factor
    Li0          =20e-9 # Size of interaction volume
    r_max        =1000e-9 # maximum radius of chromatin packing scale
    r_min        =1e-9 # size of elementary particle
    len_gene     =1e5 # average length of genes
    initial_aver =0.00056 # the average initial expression rate
    
    
    
    def Ld_D(self):
        '''
        the PWS code to transfer sigma(ld) to D
        '''
        ################# Lusik's code ########################
        Ln  = 1.50e-6;# microns
        D   = 2.66; # D of the correlation function
        L   = 3.0e-6;  # sample thickness in microns
        ##### written by L. Cherkezyan, last edited Jan 23 2016
        ##### Inplemented in Python by Wenli Wu
        #######################################################

        pi      = 3.14
        sigma_n = 0.05/1.53;
        # parameters of PWS system:
        n1      = 1;
        n2      = 1.53;
        NA      = 0.6;
        G_top   = abs(((n1-n2)/(n1+n2))**2);# Fresenel reflection at top surface
        G       = abs((n1-n2)*2*n1*2*n2/((n1+n2)**3))/G_top;
        k1      = n2*2*pi/0.7e-6;# max wavelength = 0.7um
        k2      = n2*2*pi/0.5e-6;# max wavelength = 0.5um
        kc      = (k1+k2)/2; # central wavenumber
        r_min = 1*1e-9; #um, define the minimum length scale at which RI exists
        dlist = np.zeros(100); ldList = np.zeros(100);
        D_list=np.linspace(2,2.99,100)
        qqq=0
        for D in D_list:
            An = sigma_n**2*(r_min/Ln)**(1.5-D/2)/sc.kv(D/2-1.5,r_min/Ln);# this definition of An keeps RI variance constant independent of Ln and D
            x  = kc*Ln;
            Sigma_R_2 = 2*An*(G**2*kc*L)/np.sqrt(pi)*sc.gamma(D/2)*x/((D-2)*2**(1.5-D/2))*((1+4*x**2)**(1-D/2)-(1+x**2*(4+NA**2))**(1-D/2));
            Sigma_L_2 = An*2**((D-9)/2)*G**2*sc.gamma((D-3)/2)*(1-(1+x**2*NA**2)**(1.5-D/2));
            Sigma  = np.sqrt(Sigma_R_2+Sigma_L_2);
            Ld = Sigma/np.sqrt(kc*L/n2);## sigma is variance of spectrum or mass??
            ldList[qqq] = Ld;
            qqq = qqq+1
        num = np.argmin(abs(D_list-self.D_fit))
        L_d = ldList[num] ## Ld for state one is 1 micron
        dL_d = ldList[num+1]-ldList[num]
        dD = D_list[num+1]-D_list[num]
        C0 = dD/dL_d
        return(C0,L_d,D_list,ldList)
    def se(self):
        '''
        Calculate the gene expression sensitivity using cp-mc model
        '''
        Li = (self.Li0+self.len_gene**(1/self.D_fit)*self.r_min)
        ratio = (self.r_max/self.r_min)**self.D_fit
        sigma = self.phi_initial*(1-self.phi_initial)
        sigma_phi = sigma*(Li/self.r_min)**(self.D_fit-3)
        d_sigma_phi = sigma_phi*(np.log(Li/self.r_min)+(3-self.D_fit)/self.D_fit**2*self.len_gene**(1/self.D_fit)*np.log(self.len_gene)*(self.r_min/Li)) 
        Se = (1/self.D_fit**2*np.log(ratio)+1/2*self.sec/(1+1/2*self.sec*sigma_phi)*d_sigma_phi)*self.D_fit
        initial_expression = self.initial_aver
        expression = self.mRNA_initial*(1+1/2*self.sec*sigma_phi)
        return (Se,expression,ratio)

    def se_experiment(self,n_quantile,m):
        '''
        calculate sensitivity data from experiment
        '''
        ## define the quantile by the expression of control (initial expression)
        control_norm_mean = self.data_norm[:,m+4*self.control]
        percentile_norm = np.percentile(control_norm_mean.flatten(),np.linspace(0,100,n_quantile+1)[1:]) 
        per_old = -100
        n = 0
        Se = np.zeros(n_quantile)
        for j in range(n_quantile):
            per = percentile_norm[j]
            lis, = np.where((control_norm_mean <= per)&(control_norm_mean>=per_old))         
            n = n+1
            Se_temp = np.zeros(lis.shape[0])
            for s in range(lis.shape[0]):
                ld_function = np.zeros(self.ld_exp.shape[0])
                for i in range(self.ld_exp.shape[0]):
                    ld_function[i] = self.data_norm[lis[s],(i+self.control_start)*4+m]
                temp = np.vstack((self.ld_exp,ld_function))
                a = temp.transpose()
                a = a[a[:,0].argsort()]
                Se_temp[s] = np.polyfit(a[:,0],a[:,1],1)[0]
            Se[j] = np.mean(Se_temp)
            per_old = per
        return (percentile_norm,Se)

    def func2(self,x,a):
        'the fitting function for g' 
        return a/x**(1/2)

    def g_function(self,x,popt,sigma):
        'simplied format of g function'
        return 8*x/(8*x+popt**2*sigma**2+(16*popt**2*x*sigma**2+popt**4*sigma**4)**(1/2))
       
    def g_fit(self,D):
        'g function relating epsilon_bar and epsilon(m,phi_bar)'
        epsilon_0=self.mRNA_initial[19:] # the range of mRNA_initial that makes epsilon_bar positive
        Li = (self.Li0+self.len_gene**(1/self.D_fit)*self.r_min)
        ydata=self.sec[19:]
        popt, pcov = curve_fit(self.func2, epsilon_0, ydata) # popt is the square root of kappa devided by the degradation rate of mRNA
        sigma=self.phi_initial*(1-self.phi_initial)*(Li/self.r_min)**(D-3)
        epsilon_bar=self.mRNA_initial*(1+1/2*sigma*self.sec)
        x=epsilon_bar
        g_f=self.g_function(x,popt[0],sigma)
        return (popt**2*3e-4,x,g_f) # kappa=popt^2*degradation rate of mRNA
        
    def se_g(self,x):
        'The sensitivity curve calculated by the approximation of g function'
        Li = (self.Li0+self.len_gene**(1/self.D_fit)*self.r_min)
        ratio = (self.r_max/self.r_min)**self.D_fit
        pop,a,b=self.g_fit(self.D_fit)
        pop=(pop/3e-4)**(1/2)
        sigma=self.phi_initial[25]*(1-self.phi_initial[25])*(Li/self.r_min)**(self.D_fit-3)      
        se=(1-1/self.g_function(x,pop[0],sigma))*(self.D_fit*np.log(Li/self.r_min)+(3-self.D_fit)/self.D_fit*(self.r_min/Li)*self.len_gene**(1/self.D_fit)*np.log(self.len_gene))+1/self.D_fit*np.log(ratio)
        return se




